import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../models/ayat_model.dart';
import '../../services/bookmark_service.dart';

class AyatDetailScreen extends StatefulWidget {
  final AyatModel ayat;

  const AyatDetailScreen({
    super.key,
    required this.ayat,
  });

  @override
  State<AyatDetailScreen> createState() => _AyatDetailScreenState();
}

class _AyatDetailScreenState extends State<AyatDetailScreen> {
  final BookmarkService _bookmarkService = BookmarkService();

  void _toggleBookmark() async {
    if (!_bookmarkService.canBookmark) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('বুকমার্ক করতে লগইন করুন'),
          action: SnackBarAction(
            label: 'লগইন',
            onPressed: () {
              // Navigate to profile tab (index 2)
              // This will be implemented when integrating with main navigation
            },
          ),
        ),
      );
      return;
    }

    final isNowBookmarked = await _bookmarkService.toggleBookmark(
      'ayat',
      widget.ayat.id,
      title: widget.ayat.titleBangla,
    );
    setState(() {});

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            isNowBookmarked
                ? 'বুকমার্কে যুক্ত হয়েছে'
                : 'বুকমার্ক থেকে সরানো হয়েছে',
          ),
          duration: const Duration(seconds: 1),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  void _shareAyat() async {
    try {
      final shareText = '''
${widget.ayat.titleBangla}

${widget.ayat.arabicText}

উচ্চারণ: ${widget.ayat.banglaTransliteration}

অর্থ: ${widget.ayat.banglaMeaning}

সূত্র: ${widget.ayat.reference}
''';

      await Share.share(
        shareText,
        subject: widget.ayat.titleBangla,
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('শেয়ার করতে সমস্যা হয়েছে'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  void _copyToClipboard() async {
    try {
      final copyText = '''
${widget.ayat.arabicText}

${widget.ayat.banglaMeaning}
''';

      await Clipboard.setData(ClipboardData(text: copyText));

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('ক্লিপবোর্ডে কপি হয়েছে'),
            duration: Duration(seconds: 2),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('কপি করতে সমস্যা হয়েছে'),
            backgroundColor: Colors.red,
            duration: Duration(seconds: 2),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.ayat.titleBangla,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Theme.of(context).brightness == Brightness.dark
            ? const Color(0xFF1B5E20)
            : const Color(0xFF388E3C),
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: Icon(
              _bookmarkService.isBookmarked('ayat', widget.ayat.id)
                  ? Icons.bookmark
                  : Icons.bookmark_border,
            ),
            onPressed: _toggleBookmark,
            tooltip: 'বুকমার্ক',
          ),
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: _shareAyat,
            tooltip: 'শেয়ার',
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Category Badge
                  Align(
                    alignment: Alignment.center,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? const Color(0xFF1565C0).withValues(alpha:0.2)
                            : const Color(0xFF1565C0).withValues(alpha:0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? const Color(0xFF64B5F6).withValues(alpha:0.5)
                              : const Color(0xFF1565C0).withValues(alpha:0.3),
                        ),
                      ),
                      child: Text(
                        widget.ayat.category,
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? const Color(0xFF90CAF9)
                              : const Color(0xFF1565C0),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Arabic Text
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? Colors.grey[850]
                          : Colors.grey[50],
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? const Color(0xFF81C784).withValues(alpha:0.3)
                            : const Color(0xFF1B5E20).withValues(alpha:0.2),
                        width: 2,
                      ),
                    ),
                    child: Text(
                      widget.ayat.arabicText,
                      textAlign: TextAlign.center,
                      textDirection: TextDirection.rtl,
                      style: GoogleFonts.amiri(
                        fontSize: 28,
                        fontWeight: FontWeight.w500,
                        height: 2.0,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? const Color(0xFF81C784)
                            : const Color(0xFF1B5E20),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Surah Info
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.menu_book,
                        size: 18,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? const Color(0xFF90CAF9)
                            : const Color(0xFF1565C0),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '${widget.ayat.surahName}, আয়াত ${widget.ayat.ayatNumber}',
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? const Color(0xFF90CAF9)
                              : const Color(0xFF1565C0),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),

                  // Divider
                  const Divider(thickness: 1.5),
                  const SizedBox(height: 24),

                  // Transliteration Section
                  _buildSectionHeader('বাংলা উচ্চারণ', Icons.record_voice_over),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? const Color(0xFF1565C0).withValues(alpha:0.15)
                          : Colors.blue[50],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      widget.ayat.banglaTransliteration,
                      style: TextStyle(
                        fontSize: 19,
                        fontStyle: FontStyle.italic,
                        height: 1.7,
                        color: Theme.of(context).brightness == Brightness.dark
                            ? Colors.grey[300]
                            : Colors.grey[800],
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Divider
                  const Divider(thickness: 1.5),
                  const SizedBox(height: 24),

                  // Meaning Section
                  _buildSectionHeader('বাংলা অর্থ', Icons.translate),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Theme.of(context).brightness == Brightness.dark
                          ? const Color(0xFF1565C0).withValues(alpha:0.2)
                          : const Color(0xFF1565C0).withValues(alpha:0.05),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: Theme.of(context).brightness == Brightness.dark
                            ? const Color(0xFF64B5F6).withValues(alpha:0.4)
                            : const Color(0xFF1565C0).withValues(alpha:0.2),
                      ),
                    ),
                    child: Text(
                      widget.ayat.banglaMeaning,
                      style: TextStyle(
                        fontSize: 19,
                        height: 1.8,
                        color: Theme.of(context).textTheme.bodyLarge?.color ?? Colors.black87,
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Divider
                  const Divider(thickness: 1.5),
                  const SizedBox(height: 24),

                  // Reference Section
                  Row(
                    children: [
                      Icon(
                        Icons.library_books,
                        size: 18,
                        color: Colors.grey[600],
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          widget.ayat.reference,
                          style: TextStyle(
                            fontSize: 14,
                            fontStyle: FontStyle.italic,
                            color: Colors.grey[600],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 32),

                  // Action Buttons
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: _copyToClipboard,
                          icon: const Icon(Icons.copy),
                          label: const Text('কপি'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Theme.of(context).brightness == Brightness.dark
                                ? const Color(0xFF90CAF9)
                                : const Color(0xFF1565C0),
                            side: BorderSide(
                              color: Theme.of(context).brightness == Brightness.dark
                                  ? const Color(0xFF90CAF9)
                                  : const Color(0xFF1565C0),
                              width: 2,
                            ),
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _shareAyat,
                          icon: const Icon(Icons.share),
                          label: const Text('শেয়ার'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Theme.of(context).brightness == Brightness.dark
                                ? const Color(0xFF0D47A1)
                                : const Color(0xFF1565C0),
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Row(
      children: [
        Icon(
          icon,
          size: 20,
          color: Theme.of(context).brightness == Brightness.dark
              ? const Color(0xFF90CAF9)
              : const Color(0xFF1565C0),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Theme.of(context).brightness == Brightness.dark
                ? const Color(0xFF90CAF9)
                : const Color(0xFF1565C0),
          ),
        ),
      ],
    );
  }
}
